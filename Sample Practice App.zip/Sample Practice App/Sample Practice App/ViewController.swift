//
//  ViewController.swift
//  Sample Practice App
//
//  Created by Palavelli,Bala Harinadh on 1/26/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var InputOutlet1: UITextField!
    
    @IBOutlet weak var InputOutlet2: UITextField!
    
    @IBOutlet weak var DisplayLabelOutput: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func SubmitButton(_ sender: Any) {
    //Read the Course1 name and store it in a variable1
        var course1=InputOutlet1.text!
        
        //Read the Course2 name and store it in a variable2
        var course2=InputOutlet2.text!
        //
        DisplayLabelOutput.text="\(course1)-\(course2)"
    }
}

