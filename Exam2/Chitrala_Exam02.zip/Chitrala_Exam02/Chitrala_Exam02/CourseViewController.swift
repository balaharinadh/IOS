//
//  CourseViewController.swift
//  Chitrala_Exam02
//
//  Created by Chitrala,Bhanuteja on 4/11/23.
//

import UIKit

class CourseViewController: UIViewController {

    var sid=""
    var courseId=""
    var courseName=""
    var imageName=""
    
    @IBOutlet weak var sidLabel: UILabel!
    
    
    @IBOutlet weak var courseDetailsLabel: UILabel!
    
    @IBOutlet weak var imageOL: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        sidLabel.text="Your student id is "+sid
        courseDetailsLabel.text="You have successfully enrolled in "+courseId+", "+courseName
        imageOL.image=UIImage(named: imageName)
        
        var height=imageOL.frame.height+60
        var width=imageOL.frame.width+50
        var x=imageOL.frame.origin.x-20
        var y=imageOL.frame.origin.y-20
        
        var newFrame=CGRect(x: x, y: y, width: width, height: height)
        
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.2, initialSpringVelocity: 60, animations: {
            self.imageOL.frame=newFrame
        })
        // Do any additional setup after loading the view.
    }
    

    
    @IBOutlet weak var backButton: UINavigationItem!
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
