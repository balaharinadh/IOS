//
//  ViewController.swift
//  Chitrala_Exam02
//
//  Created by Chitrala,Bhanuteja on 4/11/23.
//

import UIKit

class ViewController: UIViewController {

   
    var courses=CoursesArray
    
    var course1=CourseDetails()
    
    @IBOutlet weak var courseOL: UITextField!
    
    
    @IBOutlet weak var studentIDOL: UITextField!
    
    
    @IBOutlet weak var statusLabel: UILabel!
    
   
    @IBOutlet weak var imageOL: UIImageView!
    @IBOutlet weak var courseCheck: UIButton!
    
    
    @IBOutlet weak var enrollCourse: UIButton!
    
    
    @IBAction func courseEntered(_ sender: Any) {
        courseCheck.isEnabled=true
    }
    
    @IBAction func coursesCheck(_ sender: Any) {
        var cId=courseOL.text!
        var isFound=false
        for course in courses {
            if course.courseID==cId{
                statusLabel.text=course.courseID+" is open for registration"
                imageOL.image=UIImage(named: course.courseImage)
                enrollCourse.isHidden=false
                isFound=true
                course1=course
            }
        }
        
        if isFound==false{
            statusLabel.text="Course Id not found"
            imageOL.image=UIImage(named: "default")
        }
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        courseCheck.isEnabled=false
        
        enrollCourse.isHidden=true
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var trans=segue.identifier
        
        if trans=="CourseSegue"{
            var des=segue.destination as! CourseViewController
            des.sid=studentIDOL.text!
            des.courseId=course1.courseID
            des.courseName=course1.courseName
            des.imageName=course1.courseImage
        }
    }
    

}

