//
//  ViewController.swift
//  BMIDemoApp
//
//  Created by Palavelli,Bala Harinadh on 4/10/23.
//

import UIKit

class HomeviewController: UIViewController {

    @IBOutlet weak var HeightOutlet: UITextField!
    
    @IBOutlet weak var WeightOutlet: UITextField!
    
    @IBOutlet weak var calcweight: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    var BMI = 0.0

    @IBAction func ButtonClicked(_ sender: Any) {
        var height = Double(HeightOutlet.text!)
        print(height!)
        
        var weight = Double(WeightOutlet.text!)
        print(weight)
        
        BMI = Double(weight!/(height!*height!))
        BMI = round((BMI*100))/100
        print(BMI)
        //print(totalBill)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "ResultSegue"{
            //Create a desination
            var destination = segue.destination as! ResultViewController
            
                       destination.bmi = BMI
            
        }
    }
    
}

