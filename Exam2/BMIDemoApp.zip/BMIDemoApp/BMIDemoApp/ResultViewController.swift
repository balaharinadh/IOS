//
//  ResultViewController.swift
//  BMIDemoApp
//
//  Created by Palavelli,Bala Harinadh on 4/10/23.
//

import UIKit

class ResultViewController: UIViewController {
   
    var bmi = 0.0
    
    @IBOutlet weak var bmiOL: UITextField!
    
    @IBOutlet weak var imagviewOL: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        bmiOL.text! = bmiOL.text!+"\(bmi)"
        imagviewOL.image = UIImage(named: "bmi")
        
    }
    
    @IBAction func AnimateButton(_ sender: Any) {
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "animateSegue"{
            //Create a desination
            var destination = segue.destination as! AnimateViewController
            
            destination.imageName="bmi"
    }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

