//
//  AnimateViewController.swift
//  BMIDemoApp
//
//  Created by Palavelli,Bala Harinadh on 4/10/23.
//

import UIKit

class AnimateViewController: UIViewController {
var imageName=""
    @IBOutlet weak var imageviewOl: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        imageviewOl.image=UIImage(named: imageName)

        // Do any additional setup after loading the view.
        var width = imageviewOl.frame.width
               width += 40
        var height = imageviewOl.frame.height
            height = height + 40
        var x  =  imageviewOl.frame.origin.x-20
        var y = imageviewOl.frame.origin.y-20
        var largeFrame = CGRect(x: x, y: y, width: width, height: height)
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 50, animations: {
                    self.imageviewOl.frame = largeFrame
                })
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
