//
//  ViewController.swift
//  My 1st App
//
//  Created by Palavelli,Bala Harinadh on 1/26/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var FirstNameLabel: UITextField!
    
    @IBOutlet weak var MiddleNameLabel: UITextField!
    @IBOutlet weak var LastNameLabel: UITextField!
    
    @IBOutlet weak var DisplayLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func SubmitButton(_ sender: Any) {
        var fname=FirstNameLabel.text!
        var mname=MiddleNameLabel.text!
        var lname=LastNameLabel.text!
        
        DisplayLabel.text="\(fname) \(mname) \(lname)"
    }
    
}

