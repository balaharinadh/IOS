//
//  ViewController.swift
//  HelloApp
//
//  Created by Palavelli,Bala Harinadh on 1/24/23.
//

import UIKit

class ViewController: UIViewController {

  
    @IBOutlet weak var inputlname: UITextField!
    
    @IBOutlet weak var inputOutlet: UITextField!
    
    
    @IBOutlet weak var displaylabeloutlet: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    @IBAction func Submitbuttonclicked(_ sender: UIButton) {
        //Read the input from the text field and store it in a variable.
        var input=inputOutlet.text!
        var lname=inputlname.text!
        //perform the string interpolation and assign it to display label.
        displaylabeloutlet.text="Hello,\(lname) \(input)!😁"
                
    }
    

}

