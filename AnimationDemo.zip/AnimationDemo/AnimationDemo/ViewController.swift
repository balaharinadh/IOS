//
//  ViewController.swift
//  AnimationDemo
//
//  Created by Palavelli,Bala Harinadh on 4/9/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageOutlet: UIImageView!
    @IBOutlet weak var HappyOutlet: UIButton!
    @IBOutlet weak var SadOutlet: UIButton!
    @IBOutlet weak var AngryOutlet: UIButton!
    @IBOutlet weak var ShakemeOutlet: UIButton!
    @IBOutlet weak var showOutlet: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func happyButtonClicked(_ sender: Any) {
        updateAndAnimate("happy")
    }
    
    @IBAction func sadButtonClicked(_ sender: Any) {
        updateAndAnimate("sad")
    }
    
    @IBAction func angryButtonClicked(_ sender: Any) {
        updateAndAnimate("angry")
    }
    
    @IBAction func shakemeButtonClicked(_ sender: Any) {
        var width = imageOutlet.frame.width
                
                width += 40
                
                var height = imageOutlet.frame.height
                
                height = height + 40
                
                var x  =  imageOutlet.frame.origin.x-20
                
                
                var y = imageOutlet.frame.origin.y-20
                
                var largeFrame = CGRect(x: x, y: y, width: width, height: height)
                
                UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 50, animations: {
                    self.imageOutlet.frame = largeFrame
                })

    }
    
    @IBAction func showButtonClicked(_ sender: Any) {
        UIView.animate(withDuration: 1, animations: {
                    //Move all the compoenets to the center and disable show button
                    self.imageOutlet.center.x = self.view.center.x
                    
                    self.HappyOutlet.center.x = self.view.center.x;
                    
                    self.SadOutlet.center.x = self.view.center.x;
                    
                    self.AngryOutlet.center.x = self.view.center.x;
                    
            self.ShakemeOutlet.center.x = self.view.center.x
                    
                })
                
                showOutlet.isEnabled = false
    }
    func updateAndAnimate(_ imageName : String){
            
            //making the current image opaque.
            UIView.animate(withDuration: 1, animations: {
                self.imageOutlet.alpha = 0
            })
            
            //Assign the new image with animation and make it transparent. (alpha = 1)
            
            UIView.animate(withDuration: 1, delay:0.5, animations: {
                self.imageOutlet.alpha = 1
                self.imageOutlet.image = UIImage(named: imageName)
            })
            

        }
}

