//
//  ViewController.swift
//  ImageApp
//
//  Created by Palavelli,Bala Harinadh on 2/26/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var displayLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func displayImage(_ sender: Any) {
        displayLabel.text = "The Greatest Indian Captain"
        imageView.image = UIImage(named: "dhoni")
    }
    

}

