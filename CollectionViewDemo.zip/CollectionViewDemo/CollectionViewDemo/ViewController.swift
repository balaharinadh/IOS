//
//  ViewController.swift
//  CollectionViewDemo
//
//  Created by Palavelli,Bala Harinadh on 4/20/23.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "movieCell", for: indexPath) as! MovieCollectionViewCell
        //populate a cell
        cell.assignMovies(movie: movies[indexPath.row])
        //return cell
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        titleOL.text = "Title :\(movies[indexPath.row].title)"
        yearReleasedOL.text = "Year Released is :\(movies[indexPath.row].releasedYear)"
        boxOfficeOL.text = "Box office collection is :\(movies[indexPath.row].boxOffice)"
        ratingOL.text = "Movie Rating is :\(movies[indexPath.row].movieRating)"
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        collectionViewOL.delegate = self
        collectionViewOL.dataSource = self
    }

    @IBOutlet weak var titleOL: UILabel!
    
    @IBOutlet weak var yearReleasedOL: UILabel!
    @IBOutlet weak var ratingOL: UILabel!
    
    @IBOutlet weak var boxOfficeOL: UILabel!
    
    @IBOutlet weak var collectionViewOL: UICollectionView!
}

