//
//  MovieCollectionViewCell.swift
//  CollectionViewDemo
//
//  Created by Palavelli,Bala Harinadh on 4/20/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {

    
    @IBOutlet weak var imagevViewOl: UIImageView!
    func assignMovies(movie : Movie){
        imagevViewOl.image = movie.image
    }
}
