//
//  ViewController.swift
//  TableViewDemo
//
//  Created by Palavelli,Bala Harinadh on 4/13/23.
//

import UIKit

class Product{
    var name : String?
    var category : String?
    
    init(name: String, category: String) {
        self.name = name
        self.category = category
    }
}
class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //Expecting to return no of products
        return products.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //create a cell
        var myCell = tableViewOutlet.dequeueReusableCell(withIdentifier: "reUsableCell", for: indexPath)
        //popolate a cell with data
        myCell.textLabel?.text = products[indexPath.row].name
        //return a cell
        return myCell
      
    }
    

    @IBOutlet weak var tableViewOutlet: UITableView!
    
    var products = [Product]()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableViewOutlet.delegate = self
        tableViewOutlet.dataSource = self
        let p1 = Product(name: "MacBook", category: "Laptop")
        products.append(p1)
        let p2 = Product(name: "iphone", category: "Phone")
        products.append(p2)
        let p3 = Product(name: "ipods", category: "Accessories")
        products.append(p3)
        let p4 = Product(name: "iwatch", category: "Watch")
        products.append(p4)
        let p5 = Product(name: "BMW", category: "Cars")
        products.append(p5)
        
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "DetailsSegue"{
            let destination = segue.destination as! ResultViewController
            
            //Send the Selected Product row
            destination.product = products[(tableViewOutlet.indexPathForSelectedRow?.row)!]
        }
    }


}

