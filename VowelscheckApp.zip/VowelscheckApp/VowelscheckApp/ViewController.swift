//
//  ViewController.swift
//  VowelscheckApp
//
//  Created by Palavelli,Bala Harinadh on 1/31/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var InputOutlet: UITextField!
    
    @IBOutlet weak var OutputLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func SubmitButton(_ sender: Any) {
        //Enter the input text
        var name=InputOutlet.text!
        var txt=name.lowercased()
        
        if txt.contains("a") || txt.contains("e")||txt.contains("i") || txt.contains("o") || txt.contains("u")
        {
            OutputLabel.text="The Entered Text has a Vowel😊"
        }
        else
        {
            OutputLabel.text="The Entered Text has no Vowels☹️"
        }
        }
    
    
}

