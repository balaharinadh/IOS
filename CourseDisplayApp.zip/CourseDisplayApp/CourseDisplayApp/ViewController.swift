//
//  ViewController.swift
//  CourseDisplayApp
//
//  Created by Palavelli,Bala Harinadh on 3/16/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var DisplayImage: UIImageView!
    
    @IBOutlet weak var CourseNumOl: UILabel!
    
    @IBOutlet weak var CourseTitleOl: UILabel!
    
    @IBOutlet weak var SemOfferedOl: UILabel!
    var imageNumber = 0
    let courses = [["img01", "44555","Network Security","Fall 2022"],
                   ["img02", "44643","ios","Spring 2023"],
                   ["img03", "44656","Streaming data","Fall 2024"]]
    override func viewDidLoad() {
        super.viewDidLoad()
        //load the first image in the 0th position
        DisplayImage.image = UIImage(named: courses[0][0])
        //load the course details (number,title and semester)
        CourseNumOl.text = courses[0][1]
        CourseTitleOl.text = courses[0][2]
        SemOfferedOl.text = courses[0][3]
        //previous button disabled
        PrevOl.isEnabled = false
        //nextbutton enabled
        NextOl.isEnabled = true
        // Do any additional setup after loading the view.
    }
    
    @IBAction func PreviousButtonClicked(_ sender: UIButton) {
        //increment the image number
        imageNumber -= 1
        UpdateCourseDeails(imageNumber)
        //update the course details(image,num,title, and sem offered)
        
        //next button should be enabled
        NextOl.isEnabled = true
        //when we reach the end of the array,prev button should be disabled
        if(imageNumber == 0){
            PrevOl.isEnabled = false
            
        }
    }
    
    @IBAction func NextButtonClicked(_ sender: Any) {
        //increment the image number
        imageNumber += 1
        UpdateCourseDeails(imageNumber)
        //update the course details(image,num,title, and sem offered)
        
        //pre button should be enabled
        PrevOl.isEnabled = true
        //when we reach the end of the array,next button should be disabled
        if(imageNumber == courses.count-1){
            NextOl.isEnabled = false
            
        }
    }
    
    @IBOutlet weak var PrevOl: UIButton!
    @IBOutlet weak var NextOl: UIButton!
    
    func UpdateCourseDeails(_ imageNumber:Int){
        DisplayImage.image = UIImage(named: courses[imageNumber][0])
        CourseNumOl.text = courses[imageNumber][1]
        CourseTitleOl.text = courses[imageNumber][2]
        SemOfferedOl.text = courses[imageNumber][3]
    }
}

